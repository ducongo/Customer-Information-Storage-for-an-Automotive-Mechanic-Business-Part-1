Author: Parfait kingwaya
Student Number: 101000644
Date: 02/02/2018
Course: 2404B
Title: Assignment 1

Purpose:

Small program which could be used by an automotive mechanic
business to keep track of their customers and their vehicles. 

Copilation:

While in the propper directory in the using the terminal enter the following commands

>gcc -Wall -o assignment1 assignment1.c
>./assignment1

Expected output:

	Maurice Mooney, 1 vehicle(s)                                                                                             

	2007 Ford Fiesta, Red, 100000KM                                                                                          

                                                                                                                         

	Abigail Atwood, 1 vehicle(s)                                                                                             
	2016 Subaru Forester, Green, 40000KM                                                                                     

                                                                                                                         

	Brook Banding, 2 vehicle(s)                                                                                              

	1972 Volkswagen Beetle, White, 5000KM                                                                                    

	1972 Volkswagen Beetle, White, 5000KM                                                                                    

                                                                                                                         

	Ethan Esser, 1 vehicle(s)                                                                                                

	2010 Toyota Camry, Black, 50000KM                                                                                        

                                                                                                                         

	Eve Engram, 3 vehicle(s)                                                                                                 

	2013 Toyota Corolla, Green, 80000KM                                                                                      

	2015 Toyota Rav4, Gold, 20000KM                                                                                          

	2017 Toyota Prius, Blue, 0KM                                                                                             

                                                                                                                         

	Victor Vanvalkenburg,, 4 vehicle(s)                                                                                      

	2012 GM, Envoy, Purple, 60000KM                                                                                          

	2016 GM, Escalade, Black, 40000KM                                                                                        

	2015 GM, Malibu, Red, 20000KM                                                                                            

	2012 GM Trailblazer, Orange, 90000KM                                                                                     

                                                                                                                         

	GOING TO ATTEMPT TO ADD VEHICLES TO THE CUSTOMER WITH 4 VEHICLES ALREADY                                                  

	CANNOT ADD ANOTHER VEHICLES!                                                                                             

                                                                                                                         

	GOING TO ATTEMPT TO ADD VEHICLES TO THE CUSTOMER WITH LESS THAN 4 VEHICLES                                                

	SUCCESFULLY ADDED THE NEW VEHICLE!                                                                                       

                                                                                                                         

	Abigail Atwood, 2 vehicle(s)                                                                                             

	2016 Subaru Forester, Green, 40000KM                                                                                     

	2015 Testla Model S, Black, 2000KM


*********************************************************************************************************************************************************************************************

											THE END 

*****************************************************************************************************************************************************************************************8***





